/* 
 * echoservert.c - A concurrent echo server using threads
 */
/* $begin echoservertmain */
#define MAIN
#include "csapp.h"
using namespace std;

//ŽæŽ¢ËùÓÐŽò¿ªÎÄŒþ

void echo(int connfd);
void *thread(void *vargp);

int main(int argc, char **argv) 
{



	cout << "===============================================" << endl;
	cout << "              ·ÂUNIX V6++ filesystem           " << endl;
	cout << "                 hbx   2052643                 " << endl;
	cout << "===============================================" << endl;
	cout << endl;

	help();

	fstream fd;
	fd.open(DISK_NAME, ios::in);
	if (!fd.is_open()) {
		cout << "The file system does not exist, press any key to initialize..." << endl;
		while (getchar() != '\n');
		Init();
	}
	else {
		fd.close();
		cout << "File system initialization? （y/n）" << endl;
		char ch;
		if ((ch = getchar()) == 'y') {
			Init();
		}
		while (ch != '\n' && getchar() != '\n');
	}

	Activate();

	//cout << Current_Directory() << ">";
	











    int listenfd, *connfdp;
    socklen_t clientlen;
    struct sockaddr_storage clientaddr;
    pthread_t tid; 

    if (argc != 2) {
	fprintf(stderr, "usage: %s <port>\n", argv[0]);
	exit(0);
    }
    listenfd = Open_listenfd(argv[1]);

    while (1) {
        clientlen=sizeof(struct sockaddr_storage);
	connfdp = (int* )Malloc(sizeof(int)); //line:conc:echoservert:beginmalloc
	*connfdp = Accept(listenfd, (SA *) &clientaddr, &clientlen); //line:conc:echoservert:endmalloc
	Pthread_create(&tid, NULL, thread, connfdp);
    }
}

/* Thread routine */
void *thread(void *vargp) 
{  
    int connfd = *((int *)vargp);
    Pthread_detach(pthread_self()); //line:conc:echoservert:detach
    Free(vargp);                    //line:conc:echoservert:free
    echo(connfd);
    Close(connfd);
    return NULL;
}
/* $end echoservertmain */
