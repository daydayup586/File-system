#include "head.h"
#include "error.h"

//��ʼ�������ļ�ϵͳ�ռ�
void Init()
{
	//�ڵ�ǰĿ�½��ļ���Ϊ�ļ���
	fstream fd(DISK_NAME, ios::out);
	fd.close();
	//fstream sfd("superblock.img", ios::out);
	//sfd.close();


	fd.open(DISK_NAME, ios::out | ios::in | ios::binary);
	//sfd.open("superblock.img", ios::out | ios::in | ios::binary);
	//���û�д��ļ��������ʾ��Ϣ��throw����
	if (!fd.is_open()) {
		cout << "Unable to open file volume myDisk.img" << endl;
		throw(ERROR_CANT_OPEN_FILE);
	}

	//��SuperBlock���г�ʼ��
	SuperBlock superblock;
	superblock.s_inodenum = INODE_NUM;
	//�ܿ��� = Block�� + SuperBlock��ռ���� + Inodeλͼ��ռ����+ Inode��ռ����
	superblock.s_blocknum = BLOCK_NUM + BLOCK_POSITION;
	superblock.s_finodenum = INODE_NUM - 2;              //�������Ѿ�����
	superblock.s_fblocknum = BLOCK_NUM - 2;              //�������Ѿ�����
	//ֱ�ӹ�����Block�ռ䣨0-49��
	for (int i = 0; i < FREE_BLOCK_GROUP_NUM; i++)
		superblock.s_free[i] = FREE_BLOCK_GROUP_NUM - 1 - i;
	superblock.s_nfree = FREE_BLOCK_GROUP_NUM - 1 - 2;//�������Ѿ�����
	//д���ڴ�
	fd.seekg(SUPERBLOCK_POSITION * BLOCK_SIZE, ios::beg);
	fd.write((char*)&superblock, sizeof(superblock));


	//sfd.seekg(0, ios::beg);
	//sfd.write((char*)&superblock, sizeof(superblock));
	//sfd.close();


	//���г�������
	unsigned int stack[FREE_BLOCK_GROUP_NUM];
	for (int i = 2; i <= BLOCK_NUM / FREE_BLOCK_GROUP_NUM; i++) {
		for (unsigned j = 0; j < FREE_BLOCK_GROUP_NUM; j++) { //i=2ʱ��ռ��1�ſ�
			stack[j] = FREE_BLOCK_GROUP_NUM * i - 1 - j;      //ÿһ���ڲ����ŷ�
		}
		if (i == BLOCK_NUM / FREE_BLOCK_GROUP_NUM)
			stack[0] = 0;
		//д���ڴ�
		if (i != BLOCK_NUM / FREE_BLOCK_GROUP_NUM)  /////////////////*
			fd.seekg((BLOCK_POSITION + stack[0] - FREE_BLOCK_GROUP_NUM) * BLOCK_SIZE, ios::beg);//ÿһ������һ���������һ������п飬���һ���ջ�׹����ŵ�һ��
		else
			fd.seekg((BLOCK_POSITION + BLOCK_NUM - FREE_BLOCK_GROUP_NUM - 1) * BLOCK_SIZE, ios::beg);
		fd.write((char*)&stack, sizeof(stack));
	}

	//��ʼ��λͼ����ʼ��ǰ����Ϊ1��ʣ�µ��ڶ���ʱ�Ѿ�����Ϊ0��
	unsigned int inode_bitmap[INODE_NUM] = { 0 };
	inode_bitmap[0] = 1;
	inode_bitmap[1] = 1;
	//д���ڴ�
	//д���ڴ�
	fd.seekg(INODE_BITMAP_POSITION * BLOCK_SIZE, ios::beg);
	fd.write((char*)inode_bitmap, sizeof(unsigned int) * INODE_NUM);

	//������Ŀ¼
	Inode Inode_root;
	Inode_root.i_number = 0;//Inode�ı��
	Inode_root.i_addr[0] = 0;//��Ӧ0��Block
	Inode_root.i_mode = Inode::IDIRECTORY;//Ŀ¼
	Inode_root.i_count = 0;//���ü���
	Inode_root.i_uid = 0;//����Ա
	Inode_root.i_gid = 1;//�ļ������ߵ����ʶ
	Inode_root.i_size = 0;//Ŀ¼��СΪ0
	Inode_root.i_time = time(NULL);//������ʱ��
	Inode_root.i_permission = 0777;
	//д���ڴ�
	fd.seekg(INODE_POSITION * BLOCK_SIZE, ios::beg);
	fd.write((char*)&Inode_root, sizeof(Inode_root));
	//0��Blockд��Directory
	Directory root_directory;
	strcpy(root_directory.d_filename[0], ".");//0���Լ�
	root_directory.d_inodenumber[0] = 0;
	strcpy(root_directory.d_filename[1], "..");//1�Ǹ��ף��˴������Լ���
	root_directory.d_inodenumber[1] = 0;
	for (int i = 2; i < SUBDIRECTORY_NUM; i++) {
		root_directory.d_filename[i][0] = '\0';
	}
	for (int i = 2; i < SUBDIRECTORY_NUM; i++) {
		root_directory.d_inodenumber[i] = -1;
	}
	fd.seekg(BLOCK_POSITION * BLOCK_SIZE, ios::beg);
	fd.write((char*)&root_directory, sizeof(root_directory));

	//�����û��ļ�
	Inode Inode_accounting;
	Inode_accounting.i_number = 1;//Inode�ı��
	Inode_accounting.i_addr[0] = 1;//��Ӧ1��Block
	Inode_accounting.i_mode = Inode::IFILE;//�ļ�
	Inode_accounting.i_count = 0;//���ü���
	Inode_accounting.i_permission = 0700;//����Ա�ɶ�д
	Inode_accounting.i_uid = 0;//����Ա
	Inode_accounting.i_gid = 1;//�ļ������ߵ����ʶ
	Inode_accounting.i_size = 0;//Ŀ¼��СΪ1
	Inode_accounting.i_time = time(NULL);//������ʱ��
	//д���ڴ�
	fd.seekg(INODE_POSITION * BLOCK_SIZE + INODE_SIZE, ios::beg);
	fd.write((char*)&Inode_accounting, sizeof(Inode_accounting));

	//���������˻�
	User user;
	strcpy(user.u_name[0], "root");
	strcpy(user.u_password[0], "root");
	strcpy(user.u_name[1], "hello");
	strcpy(user.u_password[1], "hello");
	user.u_id[0] = 0;
	user.u_id[1] = 1;
	for (int i = 2; i < USER_NUM; i++) {
		user.u_id[i] = -1;
	}
	for (int i = 2; i < USER_NUM; i++) {
		user.u_name[i][0] = '\0';
	}
	for (int i = 2; i < USER_NUM; i++) {
		user.u_password[i][0] = '\0';
	}
	user.u_gid[0] = 1;
	user.u_gid[1] = 2;
	//д���ڴ�
	fd.seekg(BLOCK_POSITION * BLOCK_SIZE + Inode_accounting.i_addr[0] * BLOCK_SIZE, ios::beg);
	fd.write((char*)&user, sizeof(user));

	//�����Ŀ¼
	fd.seekg(BLOCK_POSITION * BLOCK_SIZE, ios::beg);
	fd.read((char*)&directory, sizeof(directory));

	fd.close();

	//��root�û������ļ�Ŀ¼
	user_id = 0;
	Create_Directory("bin");
	Create_Directory("etc");
	Create_Directory("home");
	Create_Directory("dev");
	Open_Directory("./home");
	Create_Directory("texts");
	Create_Directory("reports");
	Create_Directory("photos");
	Open_Directory("./texts");
	Create_File("test.txt");

}

//���ļ�ϵͳ
void Activate()
{
	//���ļ���
	fd.open(DISK_NAME, ios::out | ios::in | ios::binary);
	//���û�д��ļ��������ʾ��Ϣ��throw����
	if (!fd.is_open()) {
		cout << "Unable to open file volume myDisk.img" << endl;
		throw(ERROR_CANT_OPEN_FILE);
	}

	//��ȡ��ǰĿ¼
	fd.seekg(BLOCK_POSITION * BLOCK_SIZE, ios::beg);        //************//
	fd.read((char*)&directory, sizeof(directory));

	//������inode�Ĵ�������
	unsigned int inode_bitmap[INODE_NUM];
	Read_InodeBitMap(inode_bitmap);
	for (int i = 0; i < INODE_NUM; i++) {
		if (inode_bitmap[i] == 1) {
			Inode inode;
			Read_Inode(inode, i);
			inode.i_count = 0;
			Write_Inode(inode, i);
		}
	}

	fd.close();

	user_id = -1;
}

//�����ĵ�������˵��ָ���ʽ�ȵ�
void help()
{
	cout << "For more information about a command, type the HELP command name" << endl;
	cout << "HELP           HELP DOCUMENTATION." << endl;
	cout << "ATTRIB         Display or change file properties." << endl;
	cout << "CD             Display the name of the current directory or change it." << endl;
	cout << "DEL            Delete at least one file." << endl;
	cout << "DIR            Displays the files and subdirectories in one directory." << endl;
	cout << "EXIT           Exit the file system." << endl;
	cout << "MKDIR          Create a directory." << endl;
	cout << "RMDIR          Delete a directory." << endl;
	cout << "PRINT          Print the contents of the file." << endl;
	cout << "WRITE          Write to the file" << endl;
	cout << "OPEN           Open a file" << endl;
	cout << "CLOSE          Close a file" << endl;
	cout << "CREATE         Cpen a file" << endl;
	cout << "OPENLIST       List of currently open files" << endl;
	cout << "FSEEK          Change the pointer to a file" << endl;
	cout << "LOGOUT         The user logs out" << endl;
	cout << "WHOAMI         Displays the current user information" << endl;
	cout << "FORMAT         Format the file volume" << endl;
	cout << "REGISTER       User registration (under root)" << endl;
	cout << "DELETEACCOUNT  Delete user (under root)" << endl;
	cout << "SU             Change the user" << endl;
	cout << "CHGRP          Change the group to which the user belongs (under the root user)" << endl;
	cout << "USERLIST       Show all user information (under root)" << endl;
	cout << "" << endl;
	cout << "" << endl;
	cout << "" << endl;

}

void help_attrib()
{
	cout << "Change the read-write properties of the file" << endl;
	cout << endl;
	cout << "ATTRIB [+R | -R] [+W | -W] [+E | -E] [O | G | E] [path][filename]" << endl;
	cout << endl;
	cout << "  +   Set properties." << endl;
	cout << "  -   Clear the property." << endl;
	cout << "  R   Read file properties." << endl;
	cout << "  W   Write file properties." << endl;
	cout << "  E   Perform file attributes." << endl;
	cout << "  /O  File owner user." << endl;
	cout << "  /G  Files in the same group user." << endl;
	cout << "  /E  Users who are not file owners, non-file co-groupers" << endl;
	cout << "[path][filename]" << endl;
	cout << "      Specifies the file to be processed by the property." << endl;
}

void help_cd()
{
	cout << "Display the current directory name or change the current directory." << endl;
	cout << endl;
	cout << "CD [path]" << endl;
	cout << endl;
	cout << "Type CD without parameters to display the current drive and directory." << endl;
	cout << "Path rules: Represents this directory,.. Represents the parent directory, with paths separated by / or \\" << endl;
}
void help_del()
{
	cout << "Delete one or more files." << endl;
	cout << endl;
	cout << "DEL names" << endl;
	cout << endl;
	cout << "Delete multiple or one file." << endl;
	cout << "A user cannot delete a file without closing it." << endl;
}
void help_dir()
{
	cout << "Displays a list of files and subdirectories in the directory." << endl;
	cout << endl;
	cout << "DIR [/Q]" << endl;
	cout << endl;
	cout << "  /Q  Show details." << endl;
}
void help_exit()
{
	cout << "Quit the program (file system)." << endl;
	cout << endl;
	cout << "DIR [exitCode]" << endl;
	cout << endl;
	cout << "  exitCode    Specify a numeric number. If exiting, set the procedure exit code with that number." << endl;
}
void help_mkdir()
{
	cout << "Create a directory." << endl;
	cout << endl;
	cout << "MKDIR dir" << endl;
	cout << endl;
	cout << "  dir    The name of the directory created." << endl;
}
void help_rmdir()
{
	cout << "Delete a directory." << endl;
	cout << endl;
	cout << "MKDIR dir" << endl;
	cout << endl;
	cout << "  dir    The name of the directory to be deleted (only empty directories can be deleted)." << endl;
}
void help_print()
{
	cout << "Print the text file." << endl;
	cout << endl;
	cout << "PRINT filename [-l length] [-p path]" << endl;
	cout << endl;
	cout << "  filename The name of the printed file." << endl;
	cout << "  length   The length of the print, all printed by default" << endl;
	cout << "  path     Optionally, print the file name to the directory where the file system is located." << endl;
}
void help_write()
{
	cout << "Print the text file." << endl;
	cout << endl;
	cout << "PRINT [filename] [-s|-f] [path|content]" << endl;
	cout << endl;
	cout << "  filename The name of the file written." << endl;
	cout << "  -s      Write from the screen." << endl;
	cout << "  -f      Write from the file." << endl;
	cout << "  path    The name of the file written to the directory where the file system is located." << endl;
	cout << "  content Write the contents of the file." << endl;
}
void help_open()
{
	cout << "Open the file." << endl;
	cout << endl;
	cout << "OPEN [filename]" << endl;
	cout << endl;
	cout << "  filename The name of the file that was opened." << endl;
}
void help_close()
{
	cout << "Close the file." << endl;
	cout << endl;
	cout << "CLOSE [filename]" << endl;
	cout << endl;
	cout << "  filename The name of the closed file." << endl;
}
void help_fseek()
{
	cout << "Change the file pointer." << endl;
	cout << endl;
	cout << "FSEEK filename pos" << endl;
	cout << endl;
	cout << "  filename   File name." << endl;
	cout << "  pos        The file pointer position position." << endl;
}
void help_create()
{
	cout << "Create a file." << endl;
	cout << endl;
	cout << "CREATE filename" << endl;
	cout << endl;
	cout << "  filename File name." << endl;
}
void help_logout()
{
	cout << "The user logs out." << endl;
	cout << endl;
	cout << "LOGOUT" << endl;
}
void help_whoami()
{
	cout << "Gets the currently logged-on user." << endl;
	cout << endl;
	cout << "WHOAMI" << endl;
}
void help_format()
{
	cout << "Format the file volume." << endl;
	cout << endl;
	cout << "FORMAT" << endl;
}
void help_register()
{
	cout << "Create a new user." << endl;
	cout << endl;
	cout << "REGISTER username password" << endl;
	cout << "  username " << endl;
	cout << "  password " << endl;
}
void help_deleteaccount()
{
	cout << "Delete a user." << endl;
	cout << endl;
	cout << "DELETEACCOUNT username" << endl;
	cout << "  username " << endl;
}
void help_su()
{
	cout << "Change the user" << endl;
	cout << endl;
	cout << "SU username password" << endl;
	cout << "  username " << endl;
	cout << "  password " << endl;
}
void help_chgrp()
{
	cout << "Change the group to which the user belongs" << endl;
	cout << endl;
	cout << "CHGRP username usergroupid" << endl;
	cout << "  username    " << endl;
	cout << "  usergroupid " << endl;
}
void help_userlist()
{
	cout << "Displays all user information" << endl;
	cout << endl;
	cout << "USERLIST" << endl;
}
void help_openlist()
{
	cout << "Displays a list of all open files" << endl;
	cout << endl;
	cout << "OPENLIST" << endl;
}
