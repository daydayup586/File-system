#define MAIN
#include "head.h"
//ÃüÁîŽŠÀíËùÓÃµÄÍ·ÎÄŒþ
#include <vector>
#include <sstream>
#include <algorithm>
#include <map>

//ŽæŽ¢ËùÓÐŽò¿ªÎÄŒþ
map<string, File*> file_open;

vector<string> split(string str)
{
	string buf;
	stringstream ss(str);
	vector<string> v;
	// ×Ö·ûÁ÷ss 
	while (ss >> buf) {
		//×ªÐ¡ÐŽ
		transform(buf.begin(), buf.end(), buf.begin(), ::tolower);
		v.push_back(buf);
	}

	return v;
}

void Switch_Demand(vector<string> demand_vector)
{
	if (demand_vector[0] == "help") {
		if (demand_vector.size() == 1) {
			help();
		}
		else if (demand_vector[1] == "attrib") {
			help_attrib();
		}
		else if (demand_vector[1] == "cd") {
			help_cd();
		}
		else if (demand_vector[1] == "del") {
			help_del();
		}
		else if (demand_vector[1] == "dir") {
			help_dir();
		}
		else if (demand_vector[1] == "exit") {
			help_exit();
		}
		else if (demand_vector[1] == "mkdir") {
			help_mkdir();
		}
		else if (demand_vector[1] == "rmdir") {
			help_rmdir();
		}
		else if (demand_vector[1] == "print") {
			help_print();
		}
		else if (demand_vector[1] == "write") {
			help_write();
		}
		else if (demand_vector[1] == "open") {
			help_open();
		}
		else if (demand_vector[1] == "close") {
			help_close();
		}
		else if (demand_vector[1] == "fseek") {
			help_fseek();
		}
		else if (demand_vector[1] == "logout") {
			help_logout();
		}
		else if (demand_vector[1] == "whoami") {
			help_whoami();
		}
		else if (demand_vector[1] == "format") {
			help_format();
		}
		else if (demand_vector[1] == "register") {
			help_register();
		}
		else if (demand_vector[1] == "deleteaccount") {
			help_deleteaccount();
		}
		else if (demand_vector[1] == "su") {
			help_su();
		}
		else if (demand_vector[1] == "chgrp") {
			help_chgrp();
		}
		else if (demand_vector[1] == "userlist") {
			help_userlist();
		}
		else if (demand_vector[1] == "create") {
			help_create();
		}
		else if (demand_vector[1] == "openlist") {
			help_openlist();
		}
		else {
			cout << "The command does not exist" << endl;
		}

	}
	else if (demand_vector[0] == "attrib") {
		if (demand_vector.size() != 4)
			cout << "ATTRIB: The command syntax is incorrect, use the \"HELP ATTRIB\" command to view the usage rules" << endl;
		else if (demand_vector[1].size() != 2)
			cout << "ATTRIB: The command syntax is incorrect, use the \"HELP ATTRIB\" command to view the usage rules" << endl;
		else if (demand_vector[1][0] != '+' && demand_vector[1][0] != '-')
			cout << "ATTRIB: The command syntax is incorrect, use the \"HELP ATTRIB\" command to view the usage rules" << endl;
		else if (demand_vector[1][1] != 'r' && demand_vector[1][1] != 'w' && demand_vector[1][1] != 'e')
			cout << "AATTRIB: The command syntax is incorrect, use the \"HELP ATTRIB\" command to view the usage rules" << endl;
		else if (demand_vector[2].size() != 1)
			cout << "ATTRIB: The command syntax is incorrect, use the \"HELP ATTRIB\" command to view the usage rules" << endl;
		else if (demand_vector[2][0] != 'o' && demand_vector[2][0] != 'g' && demand_vector[2][0] != 'e')
			cout << "ATTRIB: The command syntax is incorrect, use the \"HELP ATTRIB\" command to view the usage rules" << endl;
		else {
			unsigned int permission = 0;
			bool add;
			if (demand_vector[1][0] == '+')
				add = true;
			else
				add = false;
			if (demand_vector[1][1] == 'r' && demand_vector[2] == "o")
				permission = Inode::OWNER_R;
			else if (demand_vector[1][1] == 'w' && demand_vector[2] == "o")
				permission = Inode::OWNER_W;
			else if (demand_vector[1][1] == 'e' && demand_vector[2] == "o")
				permission = Inode::OWNER_E;
			else if (demand_vector[1][1] == 'r' && demand_vector[2] == "g")
				permission = Inode::GROUP_R;
			else if (demand_vector[1][1] == 'w' && demand_vector[2] == "g")
				permission = Inode::GROUP_W;
			else if (demand_vector[1][1] == 'e' && demand_vector[2] == "g")
				permission = Inode::GROUP_E;
			else if (demand_vector[1][1] == 'r' && demand_vector[2] == "e")
				permission = Inode::ELSE_R;
			else if (demand_vector[1][1] == 'w' && demand_vector[2] == "e")
				permission = Inode::ELSE_W;
			else if (demand_vector[1][1] == 'e' && demand_vector[2] == "e")
				permission = Inode::ELSE_E;
			Edit_File_Permission(demand_vector[3].c_str(), permission, add);
			cout << "The file read-write properties were successfully changed" << endl;
		}
	}
	else if (demand_vector[0] == "cd") {
		if (demand_vector.size() == 1) {
			cout << Current_Directory() << endl;
		}
		else {
			Open_Directory(demand_vector[1].c_str());
		}
	}
	else if (demand_vector[0] == "del") {
		if (demand_vector.size() < 2)
			cout << "DEL: The command syntax is incorrect, use the \"HELP DEL\" command to view the usage rules" << endl;
		else {
			for (int i = 1; i < demand_vector.size(); i++) {
				Delete_File(demand_vector[i].c_str());
				cout << "The file was deleted successfully" << demand_vector[i] << endl;
			}
		}
	}
	else if (demand_vector[0] == "dir") {
		if (demand_vector.size() > 2)
			cout << "DIR: The command syntax is incorrect, use the \"HELP DIR\" command to view the usage rules" << endl;
		else if (demand_vector.size() == 2 && demand_vector[1] != "/q")
			cout << "DIR: The command syntax is incorrect, use the \"HELP DIR\" command to view the usage rules" << endl;
		else {
			if (demand_vector.size() == 1)
				Show_File_List(false);
			else
				Show_File_List(true);
		}
	}
	else if (demand_vector[0] == "exit") {
		if (demand_vector.size() > 2)
			cout << "EXIT: The command syntax is incorrect, use the \"HELP EXIT\" command to view the usage rules" << endl;
		else if (demand_vector.size() == 2 && !isdigit(demand_vector[1][0]))
			cout << "EXIT: The command syntax is incorrect, use the \"HELP EXIT\" command to view the usage rules" << endl;
		else {
			if (demand_vector.size() == 1) {
				cout << "Exit the file system" << endl;
				exit(0);
			}
			else {
				cout << "Exit the file system" << endl;
				exit((int)demand_vector[1][0] - 48);
			}
		}
	}
	else if (demand_vector[0] == "mkdir") {
		if (demand_vector.size() != 2)
			cout << "MKDIR: The command syntax is incorrect, use the \"HELP MKDIR\" command to view the usage rules" << endl;
		else {
			Create_Directory(demand_vector[1].c_str());
			cout << "The catalog is successfully created" << demand_vector[1] << endl;
		}
	}
	else if (demand_vector[0] == "rmdir") {
		if (demand_vector.size() != 2)
			cout << "RMDIR: The command syntax is incorrect, use the \"HELP RMDIR\" command to view usage rules" << endl;
		else {
			Remove_Directory(demand_vector[1].c_str());
			cout << "The directory was successfully deleted" << demand_vector[1] << endl;
		}
	}
	else if (demand_vector[0] == "open") {
		if (demand_vector.size() != 2)
			cout << "OPEN: The command syntax is incorrect, use the \"HELP OPEN\" command to view the usage rules" << endl;
		else {
			File* file = Open_File(demand_vector[1].c_str());
			if (file_open.find(Current_Directory() + "\\" + demand_vector[1]) == file_open.end()) {
				file_open[Current_Directory() + "\\" + demand_vector[1]] = file;
				cout << "The file was successfully opened" << demand_vector[1] << endl;
			}
			else
			{
				cout << "The current file is already open and cannot be opened repeatedly" << endl;
			}
		}
	}
	else if (demand_vector[0] == "close") {
		if (demand_vector.size() != 2)
			cout << "CLOSE: The command syntax is incorrect, use the \"HELP CLOSE\" command to view the usage rules" << endl;
		else {
			auto it = file_open.find(Current_Directory() + "\\" + demand_vector[1]);
			if (it == file_open.end()) {
				cout << "The file is not open" << demand_vector[1] << endl;
			}
			else {
				Close_File(it->second);
				file_open.erase(it);
				cout << "The file was successfully closed" << demand_vector[1] << endl;
			}

		}
	}
	else if (demand_vector[0] == "print") {
		if (demand_vector.size() > 6)
			cout << "PRINT: The command syntax is incorrect, use the \"HELP PRINT\" command to view the usage rules" << endl;
		else {
			int length = -1;
			vector<string>::iterator it;
			for (it = demand_vector.begin(); it != demand_vector.end(); it++) {
				if (*it == "-l")
					break;
				if (it->at(0) == '-' && !(it->at(1) == 'p' || it->at(1) == 'l')) {
					cout << "PRINT: The command syntax is incorrect, use the \"HELP PRINT\" command to view the usage rules" << endl;
					return;
				}
			}
			if (it != demand_vector.end())
			{
				it++;
				if (!isdigit(it->at(0))) {
					cout << "PRINT: The command syntax is incorrect, use the \"HELP PRINT\" command to view the usage rules" << endl;
					return;
				}
				length = atoi((*it).c_str());
			}

			char* content = new char[100000000];
			auto i = file_open.find(Current_Directory() + "\\" + demand_vector[1]);
			if (i == file_open.end()) {
				cout << "The file is not open" << demand_vector[1] << endl;
				return;
			}
			int sum_len = 0;
			sum_len = Read_File(i->second, content, length);


			for (it = demand_vector.begin(); it != demand_vector.end(); it++) {
				if (*it == "-p")
					break;
			}
			if (it != demand_vector.end())
			{
				it++;
				fstream f(*it, ios::out | ios::binary);
				if (!f.is_open()) {
					cout << "Unable to open file" << *it << endl;
					return;
				}
				cout << strlen(content) << endl;
				cout << sum_len << endl;
				string result = "";
				for (int ii = 0; ii < sum_len; ii++) {
					result = result + content[ii];

				}
				f << result;
				f.close();
				cout << "File content" << demand_vector[1] << "has been write into" << *it << endl;
			}
			else {
				cout << content << endl;
			}
			delete[]content;
		}
	}
	else if (demand_vector[0] == "write") {
		if (demand_vector.size() > 4)
			cout << "WRITE: The command syntax is incorrect, use the \"HELP WRITE\" command to view the usage rules" << endl;
		else if (demand_vector[2] != "-s" && demand_vector[2] != "-f")
			cout << "WRITE: The command syntax is incorrect, use the \"HELP WRITE\" command to view the usage rules" << endl;

		else {
			auto it = file_open.find(Current_Directory() + "\\" + demand_vector[1]);
			if (it == file_open.end()) {
				cout << "The file is not open" << demand_vector[1] << endl;
				return;
			}

			if (demand_vector[2] == "-s") {
				Write_File(it->second, demand_vector[3].c_str());
				cout << "The file was successfully written" << endl;
			}
			else {
				string content;
				fstream f(demand_vector[3], ios::in | ios::binary);
				if (!f.is_open()) {
					cout << "Unable to open file" << demand_vector[2] << endl;
					return;
				}
				while (!f.eof()) {
					getline(f, content);
					content += '\n';
					Write_File(it->second, content);
				}
				f.close();
				cout << "File content" << demand_vector[3] << "has been write into" << demand_vector[1] << endl;
			}
		}
	}
	else if (demand_vector[0] == "fseek") {
		if (demand_vector.size() != 3)
			cout << "FSEEK: COMMAND SYNTAX IS INCORRECT, USE THE \"HELP FSEEK\" COMMAND TO VIEW USAGE RULES" << endl;
		else {
			auto it = file_open.find(Current_Directory() + "\\" + demand_vector[1]);
			if (it == file_open.end()) {
				cout << "The file is not open" << demand_vector[1] << endl;
			}
			else {
				Seek_File(it->second, atoi(demand_vector[2].c_str()));
				cout << "File pointer" << demand_vector[1] << "has been located in" << demand_vector[2] << endl;
			}
		}
	}
	else if (demand_vector[0] == "create") {
		if (demand_vector.size() != 2)
			cout << "CREATE: The command syntax is incorrect, use the \"HELP CREATE\" command to view the usage rules" << endl;
		else {
			Create_File(demand_vector[1].c_str());
			cout << "The file is created successfully" << demand_vector[1] << endl;
		}
	}
	else if (demand_vector[0] == "logout") {
		if (demand_vector.size() != 1)
			cout << "LOGOUT: The command syntax is incorrect, use the \"HELP LOGOUT\" command to view the usage rules" << endl;
		else {
			User_Logout();
			cout << "The user is successfully logged out" << endl;
		}
	}
	else if (demand_vector[0] == "whoami") {
		if (demand_vector.size() != 1)
			cout << "WHIAMI: The command syntax is incorrect, use the \"HELP WHIAMI\" command to view the usage rules" << endl;
		else {
			char user_name[USER_NAME_MAX];
			cout << "userid:" << Get_User(user_name) << endl;
			cout << "username:" << user_name << endl;
		}
	}
	else if (demand_vector[0] == "openlist") {
		if (demand_vector.size() != 1)
			cout << "OPENLIST: The command syntax is incorrect, use the \"HELP OPENLIST\" command to view the usage rules" << endl;
		else {
			cout << "The files currently open are:" << endl;
			for (auto& it : file_open) {
				cout << it.first << endl;
			}
		}
	}
	else if (demand_vector[0] == "format") {
		if (demand_vector.size() != 1)
			cout << "FORMAT: The command syntax is incorrect, use the \"HELP FORMAT\" command to view the usage rules" << endl;
		else {
			Init();
			Activate();
			cout << "The file volume was successfully formatted" << endl;
		}
	}
	else if (demand_vector[0] == "register") {
		if (demand_vector.size() != 3)
			cout << "REGISTER: The command syntax is incorrect, use the \"HELP REGISTER\" command to view the usage rules" << endl;
		else {
			User_Register(demand_vector[1].c_str(), demand_vector[2].c_str());
			cout << "The user is successfully created" << endl;
		}
	}
	else if (demand_vector[0] == "deleteaccount") {
		if (demand_vector.size() != 2)
			cout << "DELETEACCOUNT: The command syntax is incorrect, use the \"HELP DELETEACCOUNT\" command to view the usage rules" << endl;
		else {
			User_Delete(demand_vector[1].c_str());
			cout << "The user was successfully deleted" << endl;
		}
	}
	else if (demand_vector[0] == "su") {
		if (demand_vector.size() != 3)
			cout << "SU: The command syntax is incorrect, use the \"HELP SU\" command to view the usage rules" << endl;
		else {
			User_Logout();
			User_Login(demand_vector[1].c_str(), demand_vector[2].c_str());
			cout << "Successful user replacement" << endl;
		}
	}
	else if (demand_vector[0] == "chgrp") {
		if (demand_vector.size() != 3)
			cout << "CHGRP: The command syntax is incorrect, use the \"HELP CHGRP\" command to view the usage rules" << endl;
		else {
			Change_User_Group(demand_vector[1].c_str(), atoi(demand_vector[2].c_str()));
			cout << "Successfully changed the user" << demand_vector[1] << "to group" << demand_vector[2] << "" << endl;
		}
	}
	else if (demand_vector[0] == "userlist") {
		if (demand_vector.size() != 1)
			cout << "USERLIST: The command syntax is incorrect, use the \"HELP USERLIST\" command to view the usage rules" << endl;
		else {
			Show_User_List();
		}
	}
	else {
		cout << demand_vector[0] << "Not an internal or external command, nor a runnable program or batch file." << endl;
	}

}



int main()
{
	cout << "===============================================" << endl;
	cout << "              UNIX V6++ filesystem             " << endl;
	cout << "              houbingxuan  2052643             " << endl;
	cout << "===============================================" << endl;
	cout << endl;

	help();
	mapfd = open("superblock.img", O_CREAT | O_RDWR | O_TRUNC, 00777);
	mmapoint = (char*)mmap(NULL, sizeof(SuperBlock), PROT_READ | PROT_WRITE, MAP_SHARED, mapfd, 0);

	fstream fd;
	fd.open(DISK_NAME, ios::in);
	if (!fd.is_open()) {
		cout << "The file system does not exist, press any key to initialize..." << endl;
		while (getchar() != '\n');
		Init();
	}
	else {
		fd.close();
		cout << "File system initialization? （y/n）" << endl;
		char ch;
		if ((ch = getchar()) == 'y') {
			Init();
		}
		while (ch != '\n' && getchar() != '\n');
	}

	Activate();


	string demand;
	while (1) {
		try {
			if (Get_User(NULL) == (unsigned short)(-1)) {
				cout << "The user is not logged in, please enter the user name and password" << endl;
				cout << "Username: ";
				char user_name[USER_NAME_MAX];
				cin >> user_name;
				cout << "Password: ";
				char user_password[USER_PASSWORD_MAX];
				cin >> user_password;
				User_Login(user_name, user_password);
				getchar();
			}
			cout << Current_Directory() << ">";
			getline(cin, demand);
			vector<string> demand_vector = split(demand);

			if (demand_vector.empty())
				continue;
			else {
				Switch_Demand(demand_vector);
			}
		}
		catch (int& e) {
			cout << "【Error Code】" << e << endl;
		}
		cout << endl;
	}
	int c_ret = close(mapfd);
	int mun_ret = munmap(mmapoint, sizeof(SuperBlock));

	return 0;
}
