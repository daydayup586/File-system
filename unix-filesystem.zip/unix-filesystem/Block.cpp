//**********************ÓÐ¹ØBlockµÄ²Ù×÷µÄº¯Êý***********************
#include "head.h"
#include "error.h"



//¶Á³öSuperBlock¿é
void Read_SuperBlock(SuperBlock& superblock)
{
	fd.open(DISK_NAME, ios::out | ios::in | ios::binary);
	//如果没有打开文件则输出提示信息并throw错误
	if (!fd.is_open()) {
		cout << "无法打开文件卷myDisk.img" << endl;
		throw(ERROR_CANT_OPEN_FILE);
	}

	//从内存读出                                  mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	fd.seekg(SUPERBLOCK_POSITION * BLOCK_SIZE, ios::beg);
	fd.read((char*)&superblock, sizeof(superblock));
	fd.close();

	/*mapfd = open(DISK_NAME, O_CREAT | O_RDWR | O_TRUNC, 00777);
	superblock = (SuperBlock*)mmap(NULL, sizeof(superblock), PROT_READ | PROT_WRITE, MAP_SHARED, mapfd, 0);*/
	//superblock
}

//ÐŽSuperBlock¿é
void Write_SuperBlock(SuperBlock& superblock)
{
	fd.open(DISK_NAME, ios::out | ios::in | ios::binary);
	//如果没有打开文件则输出提示信息并throw错误
	if (!fd.is_open()) {
		cout << "无法打开文件卷myDisk.img" << endl;
		throw(ERROR_CANT_OPEN_FILE);
	}

	//写入内存                                            mmmmmmmmmmmmmmmmmmmmmmmmmm
	fd.seekg(SUPERBLOCK_POSITION * BLOCK_SIZE, ios::beg);
	fd.write((char*)&superblock, sizeof(superblock));
	fd.close();
	//int c_ret = close(mapfd);
	//int mun_ret = munmap(superblock, sizeof(superblock));//ÊÍ·ÅµôÓ³ÉäÇø¡£

}

//¶Á³öBitmap¿é
void Read_InodeBitMap(unsigned int* inode_bitmap)
{
	fd.open(DISK_NAME, ios::out | ios::in | ios::binary);
	//Èç¹ûÃ»ÓÐŽò¿ªÎÄŒþÔòÊä³öÌáÊŸÐÅÏ¢²¢throwŽíÎó
	if (!fd.is_open()) {
		cout << "Unable to open file volume myDisk.img" << endl;
		throw(ERROR_CANT_OPEN_FILE);
	}

	//ŽÓÄÚŽæ¶Á³ö                     mmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	fd.seekg(INODE_BITMAP_POSITION * BLOCK_SIZE, ios::beg);
	fd.read((char*)inode_bitmap, sizeof(unsigned int) * INODE_NUM);
	fd.close();
}

//ÐŽBitmap¿é
void Write_InodeBitMap(unsigned int* inode_bitmap)
{
	fd.open(DISK_NAME, ios::out | ios::in | ios::binary);
	//Èç¹ûÃ»ÓÐŽò¿ªÎÄŒþÔòÊä³öÌáÊŸÐÅÏ¢²¢throwŽíÎó
	if (!fd.is_open()) {
		cout << "Unable to open file volume myDisk.img" << endl;
		throw(ERROR_CANT_OPEN_FILE);
	}

	//ÐŽÈëÄÚŽæ                              mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	fd.seekg(INODE_BITMAP_POSITION * BLOCK_SIZE, ios::beg);
	fd.write((char*)inode_bitmap, sizeof(unsigned int) * INODE_NUM);
	fd.close();
}

//¶Á³öUser¿é
void Read_User(User& user)
{
	fd.open(DISK_NAME, ios::out | ios::in | ios::binary);
	//Èç¹ûÃ»ÓÐŽò¿ªÎÄŒþÔòÊä³öÌáÊŸÐÅÏ¢²¢throwŽíÎó
	if (!fd.is_open()) {
		cout << "Unable to open file volume myDisk.img" << endl;
		throw(ERROR_CANT_OPEN_FILE);
	}

	//ŽÓÄÚŽæ¶Á³ö                                                  
	//fd.seekg((BLOCK_POSITION + 1) * BLOCK_SIZE, ios::beg);    //*************//
	//fd.read((char*)&user, sizeof(user));
	fd.close();


	tool_bufferpoint = buffermanager.Bread(1);
	memcpy((char*)&user, tool_bufferpoint->addr, sizeof(user));
	buffermanager.Brelse(tool_bufferpoint);


}

//ÐŽUser¿é
void Write_User(User& user)
{
	fd.open(DISK_NAME, ios::out | ios::in | ios::binary);
	//Èç¹ûÃ»ÓÐŽò¿ªÎÄŒþÔòÊä³öÌáÊŸÐÅÏ¢²¢throwŽíÎó
	if (!fd.is_open()) {
		cout << "Unable to open file volume myDisk.img" << endl;
		throw(ERROR_CANT_OPEN_FILE);
	}

	//ÐŽÈëÄÚŽæ
	//fd.seekg((BLOCK_POSITION + 1) * BLOCK_SIZE, ios::beg);  //***************//
	//fd.write((char*)&user, sizeof(user));
	fd.close();


	tool_bufferpoint = buffermanager.GetBlk(1);
	memcpy(tool_bufferpoint->addr, (char*)&user, sizeof(user));
	buffermanager.Bwrite(tool_bufferpoint);

}

//¶Á³öInode¿é
void Read_Inode(Inode& inode, unsigned int pos)
{
	fd.open(DISK_NAME, ios::out | ios::in | ios::binary);
	//Èç¹ûÃ»ÓÐŽò¿ªÎÄŒþÔòÊä³öÌáÊŸÐÅÏ¢²¢throwŽíÎó
	if (!fd.is_open()) {
		cout << "Unable to open file volume myDisk.img" << endl;
		throw(ERROR_CANT_OPEN_FILE);
	}

	//ŽÓÄÚŽæ¶Á³ö               mmmmmmmmmmmmmmmmmmmmmmmmmmmm
	fd.seekg(INODE_POSITION * BLOCK_SIZE + pos * INODE_SIZE, ios::beg);
	fd.read((char*)&inode, sizeof(inode));
	fd.close();
}

//ÐŽInode¿é
void Write_Inode(Inode& inode, unsigned int pos)
{
	fd.open(DISK_NAME, ios::out | ios::in | ios::binary);
	//Èç¹ûÃ»ÓÐŽò¿ªÎÄŒþÔòÊä³öÌáÊŸÐÅÏ¢²¢throwŽíÎó
	if (!fd.is_open()) {
		cout << "Unable to open file volume myDisk.img" << endl;
		throw(ERROR_CANT_OPEN_FILE);
	}

	//ÐŽÈëÄÚŽæ                    mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	fd.seekg(INODE_POSITION * BLOCK_SIZE + pos * INODE_SIZE, ios::beg);
	fd.write((char*)&inode, sizeof(inode));
	fd.close();
}

//·ÖÅäÒ»žöBlock¿é
void Allocate_Block(unsigned int& block_num)
{
	SuperBlock superblock;
	//ŽÓÄÚŽæ¶Á³ö
	//Read_SuperBlock(superblock);
	//mmapoint
	// 
	memcpy((char*)&superblock, mmapoint, sizeof(SuperBlock));
	//Èç¹ûÃ»ÓÐfreeµÄÁË
	if (superblock.s_nfree == 0) {
		if (superblock.s_free[0] == 0) {             //ÒÑŸ­µœ×îºóÒ»×éÁË
			cout << "There is no room to continue allocating a Block!";
			throw(ERROR_OUT_OF_SPACE);
		}
		block_num = superblock.s_free[0];            //Ã»µœ×îºóÒ»×é£¬°ÑžÃ×é×îºóÒ»¿éÄÃ³öÀŽ£¬µ«ÊÇÕâÒ»¿é²Ø×ÅÏÂÒ»žö×éµÄË÷Òý±í
		
		
		//fd.open(DISK_NAME, ios::out | ios::in | ios::binary);                                                                //*************//
		//fd.seekg((BLOCK_POSITION + superblock.s_free[0]) * BLOCK_SIZE, ios::beg);//ÒòŽËÐèÒª°ÑË÷Òý±íÄÃ³öÀŽ£¬ÄÃµœsuperblockµÄ¿ÕÏÐ¹ÜÀí
		//fd.read((char*)&superblock.s_free, sizeof(superblock.s_free));
		//fd.close();
		
		tool_bufferpoint = buffermanager.Bread(superblock.s_free[0]);
		memcpy((char*)&superblock.s_free, tool_bufferpoint->addr, sizeof(superblock.s_free));
		buffermanager.Brelse(tool_bufferpoint);
		
		superblock.s_nfree = FREE_BLOCK_GROUP_NUM - 1;            //ÏÖÔÚ°Ñ×éÀï×îºóÒ»žö¿é·ÖÅäÁË£¬¶øsuperblock¹ÜÀíµÄÊÇÏÂÒ»žö×éµÄË÷Òý±í
	}
	else {
		block_num = superblock.s_free[superblock.s_nfree];         //»¹ÓÐfreeµÄ»°ŸÍŽÓÇ°Ïòºó¿ªÊŒÓÃ
		superblock.s_nfree--;
		superblock.s_fblocknum--;
	}

	//ÐŽÈëÄÚŽæ
	//Write_SuperBlock(superblock);
	//strcpy(mmapoint, superblock);
	memcpy(mmapoint, (char*)&superblock, sizeof(SuperBlock));
}
//ÊÍ·ÅÒ»žöBlock¿é
void Free_Block(unsigned int block_num)
{
	SuperBlock superblock;
	//ŽÓÄÚŽæ¶Á³ö
	//Read_SuperBlock(superblock);
	memcpy((char*)&superblock, mmapoint, sizeof(SuperBlock));


	//Èç¹ûžÃ¿ÕÏÐ¿éÒÑÂú£¬ÐèÒªÊ¹superblockÖžÏòÒ»žöÐÂµÄ¿Õ¿é
	if (superblock.s_nfree == FREE_BLOCK_GROUP_NUM - 1) {
		//fd.open(DISK_NAME, ios::out | ios::in | ios::binary);
		//fd.seekg((BLOCK_POSITION + block_num) * BLOCK_SIZE, ios::beg);  //superblockËù¹ÜÀíµÄ¿ÕÏÐÇøÒÑŸ­ÂúÁË£¿          //**********//
		//fd.write((char*)&superblock.s_free, sizeof(superblock.s_free)); //ÄÇÃŽÐÂµœµÄ¿éÓŠžÃÊÇÒ»žö×éµÄ×îºóÒ»¿é£¿
		//fd.close();                                                     //¶øsuperblockÏÖÓÐµÄ¿ÕÏÐ¹ÜÀíÖžµÄÊÇÏÂÒ»×é£¿

		tool_bufferpoint = buffermanager.GetBlk(block_num);
		memcpy(tool_bufferpoint->addr, (char*)&superblock.s_free, sizeof(superblock.s_free));
		buffermanager.Bwrite(tool_bufferpoint);




		superblock.s_free[0] = block_num;                               //ÏòÐÂ¿éÖÐÐŽÈëË÷Òý±í£¬±íÊŸÊÍ·ÅÕûžöÁŽ
		superblock.s_nfree = 0;                                         //Çå¿Õ¿ÕÏÐ¹ÜÀíÇøÓò
		superblock.s_fblocknum++;
	}
	else {
		superblock.s_nfree++;                                           //×¢Òâ£ºÕâÀïŒÙÉèÒ»ÇÐ¶ŒÊÇ°ŽÕÕË³ÐòÀŽµÄ£¬ÐÂÊÍ·ÅµÄ¿é±È¿ÕÏÐÇøÖÐÕ»¶¥£šË÷Òý×îŽóµÄ¿é£©Ð¡1
		superblock.s_free[superblock.s_nfree] = block_num;
	}
	//Write_SuperBlock(superblock);
	memcpy(mmapoint, (char*)&superblock, sizeof(SuperBlock));
}

//InodežùŸÝÂßŒ­¿éºÅ¶ÔÓŠÎïÀí¿éºÅ£špysical_num_1ÎªÊµŒÊÎïÀí¿éºÅ£¬pysical_num_2ÎªÆäÉÏÒ»Œ¶Ë÷ÒýÎïÀí¿éºÅ£¬pysical_num_3ÎªÆäÉÏÉÏŒ¶Ë÷ÒýÎïÀí¿éºÅ£¬£©
//×¢Òâ£¬žÃº¯ÊýÓÐÒ»žö»ù±ŸÇ°Ìá£¬ŸÍÊÇÐèÒªÎªiNodeœá¹¹·ÖÅäºÃË÷Òý£¬Ç°6žöÖ±œÓÖžÏò£¬ºó4žöÖžÏòË÷ÒýËùÔÚµÄ¿éºÅ
void Get_Block_Pysical_Num(Inode& inode, unsigned int logical_num, unsigned int& physical_num_1, unsigned int& physical_num_2, unsigned int& physical_num_3)
{
	if (logical_num <= 5) {
		physical_num_1 = inode.i_addr[logical_num];
	}
	else if (logical_num <= (BLOCK_SIZE / sizeof(unsigned int)) * 2 + 5) {
		unsigned int block_map_1_index = (logical_num - 6) / (BLOCK_SIZE / sizeof(unsigned int)) + 6;
		unsigned int block_map_1[BLOCK_SIZE / sizeof(unsigned int)];
		//ŽÓÄÚŽæ¶Á³ö
		//fd.open(DISK_NAME, ios::out | ios::in | ios::binary);
		//fd.seekg((BLOCK_POSITION + inode.i_addr[block_map_1_index]) * BLOCK_SIZE, ios::beg);  //ÀŽµœÁËµÚÒ»²ãµÄË÷ÒýÏîËùÔÚµÄ¿é      //*********//
		//fd.read((char*)&block_map_1, sizeof(block_map_1));                                    //Ö±œÓŽÓ¿éÖÐ¶ÁµÚ¶þ²ãµÄË÷Òý±í
		//fd.close();

		tool_bufferpoint = buffermanager.Bread(inode.i_addr[block_map_1_index]);
		memcpy((char*)block_map_1, tool_bufferpoint->addr, BLOCK_SIZE);
		buffermanager.Brelse(tool_bufferpoint);


		//ÕÒµœÏàÓŠµÄ¿éºÅ
		physical_num_1 = block_map_1[(logical_num - 6) % (BLOCK_SIZE / sizeof(unsigned int))];  //ÂßŒ­ºÅŒõµôÇ°ÃæµÄ²¿·ÖÔÙÈ¡Ä£
		physical_num_2 = inode.i_addr[block_map_1_index];

		//physical_num_1 = tool_bufferpoint->addr[(logical_num - 6) % (BLOCK_SIZE / sizeof(unsigned int))];  //ÂßŒ­ºÅŒõµôÇ°ÃæµÄ²¿·ÖÔÙÈ¡Ä£
		//physical_num_2 = inode.i_addr[block_map_1_index];

		

	}
	else if (logical_num <= (BLOCK_SIZE / sizeof(unsigned int)) * (BLOCK_SIZE / sizeof(unsigned int)) * 2 + (BLOCK_SIZE / sizeof(unsigned int)) * 2 + 5) {
		unsigned int block_map_2_index = (logical_num - 262) / (BLOCK_SIZE / sizeof(unsigned int)) / (BLOCK_SIZE / sizeof(unsigned int)) + 8;  //µÚÒ»²ãµÄË÷Òý
		unsigned int block_map_2[BLOCK_SIZE / sizeof(unsigned int)];																		   //µÚ¶þ²ãË÷Òý±í

		//ŽÓÄÚŽæ¶Á³ö
		//fd.open(DISK_NAME, ios::out | ios::in | ios::binary);
		//fd.seekg((BLOCK_POSITION + inode.i_addr[block_map_2_index]) * BLOCK_SIZE, ios::beg);              //***********//
		//fd.read((char*)&block_map_2, sizeof(block_map_2));
		//fd.close();

		tool_bufferpoint = buffermanager.Bread(inode.i_addr[block_map_2_index]);
		memcpy((char*)&block_map_2, tool_bufferpoint->addr, sizeof(block_map_2));
		buffermanager.Brelse(tool_bufferpoint);


		unsigned int block_map_1_index = ((logical_num - 262) / (BLOCK_SIZE / sizeof(unsigned int))) % (BLOCK_SIZE / sizeof(unsigned int));//µÚ¶þ²ãË÷Òý
		unsigned int block_map_1[BLOCK_SIZE / sizeof(unsigned int)];																	   //µÚÈý²ãË÷Òý±í

		//ŽÓÄÚŽæ¶Á³ö
		//fd.open(DISK_NAME, ios::out | ios::in | ios::binary);
		//fd.seekg((BLOCK_POSITION + block_map_2[block_map_1_index]) * BLOCK_SIZE, ios::beg);              //**************//
		//fd.read((char*)&block_map_1, sizeof(block_map_1));
		//fd.close();

		tool_bufferpoint = buffermanager.Bread(block_map_2[block_map_1_index]);
		memcpy((char*)&block_map_1, tool_bufferpoint->addr, sizeof(block_map_1));
		buffermanager.Brelse(tool_bufferpoint);


		//ÕÒµœÏàÓŠµÄ¿éºÅ
		physical_num_1 = block_map_1[(logical_num - 262) % (BLOCK_SIZE / sizeof(unsigned int))];      //ÔÚµÚÈý²ãË÷Òý±íÖÐÕÒµœÁË×îÖÕµÄÎïÀí¿éºÅ
		physical_num_2 = block_map_2[block_map_1_index];								  //ÔÚµÚ¶þ²ãË÷Òý±íÖÐÕÒµœÁËµÚÈý²ãË÷Òý±íËùÔÚµÄÎïÀí¿éºÅ
		physical_num_3 = inode.i_addr[block_map_2_index];								  //ÔÚµÚÒ»²ãË÷Òý±íÖÐÕÒµœÁËµÚ¶þ²ãË÷Òý±íËùÔÚµÄÎïÀí¿éºÅ
	}
	else {
		cout << "The logical block number exceeds the index" << endl;
		throw(ERROT_OUT_OF_RANGE);
	}


	if (physical_num_1 == 0) {
		cout << logical_num << endl;
		cout << "((((((((((((((((" << endl;
	}

}
