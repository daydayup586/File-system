//**********************�й��ļ��Ĳ����ĺ���***********************
#include "head.h"
#include "error.h"

//����һ���ļ�
void Create_File(const char* file_name)
{
	//����ļ����Ƿ�Ϸ�
	if (file_name == NULL || strlen(file_name) > FILENAME_MAX) {
		cout << "The file name is invalid" << endl;
		throw(ERROR_INVALID_FILENAME);
	}
	//ȡ��superblock
	SuperBlock superblock;
	//Read_SuperBlock(superblock);
	memcpy((char*)&superblock, mmapoint, sizeof(SuperBlock));
	//�Ƿ��п��е�block��inode
	if (superblock.s_fblocknum <= 0 || superblock.s_finodenum <= 0)
	{
		cout << "There is not enough space to create a new file" << endl;
		throw(ERROR_OUT_OF_SPACE);
	}

	//��⵱ǰĿ¼�Ƿ���ͬ���ļ�
	for (int i = 0; i < SUBDIRECTORY_NUM; i++)
	{
		if (strcmp(directory.d_filename[i], file_name) == 0)
		{
			Inode tmp_inode;
			int tmp_inode_number = directory.d_inodenumber[i];

			fd.open(DISK_NAME, ios::out | ios::in | ios::binary);
			fd.seekg(INODE_POSITION * BLOCK_SIZE + tmp_inode_number * INODE_SIZE, ios::beg);
			fd.read((char*)&tmp_inode, sizeof(tmp_inode));
			fd.close();
			if (tmp_inode.i_mode & Inode::IDIRECTORY)
				continue;
			else {
				cout << "The file name is invalid and a file named " << file_name << "already exists in the current directory" << endl;
				throw(ERROR_INVALID_FILENAME);
			}
		}
	}

	//��⵱ǰĿ¼���ļ������Ƿ�ﵽ����
	int itemCounter = 0;
	for (int i = 0; i < SUBDIRECTORY_NUM; i++)
		if (strlen(directory.d_filename[i]) > 0)
			itemCounter++;

	if (itemCounter == SUBDIRECTORY_NUM)
	{
		cout << "The current directory has reached the limit of " << SUBDIRECTORY_NUM << "and cannot continue to create files" << endl;
		throw(ERROR_OUT_OF_SPACE);
	}

	//Ѱ���µ�inode
	unsigned int inode_bitmap[INODE_NUM];
	Read_InodeBitMap(inode_bitmap);

	int new_inode_index = 0;
	unsigned int new_block_addr = -1;
	for (; new_inode_index < INODE_NUM; new_inode_index++)
		if (inode_bitmap[new_inode_index] == 0)
			break;

	//����User�ṹ��
	User user;
	Read_User(user);
	//�����µ�Inode
	Inode new_inode;
	new_inode.i_number = new_inode_index;//Inode�ı��
	new_inode.i_mode = Inode::IFILE;//�ļ�
	new_inode.i_size = 0;
	new_inode.i_uid = user_id;
	new_inode.i_gid = user.u_gid[user_id];
	new_inode.i_permission = 0777;
	new_inode.i_count = 0;
	new_inode.i_time = time(NULL);
	//д��Inode���ڴ�
	fd.open(DISK_NAME, ios::out | ios::in | ios::binary);
	fd.seekg(INODE_POSITION * BLOCK_SIZE + new_inode.i_number * INODE_SIZE, ios::beg);
	fd.write((char*)&new_inode, sizeof(new_inode));
	fd.close();

	//����λʾͼ
	inode_bitmap[new_inode.i_number] = 1;
	Write_InodeBitMap(inode_bitmap);

	//����Ŀ¼
	int directory_inode_index = directory.d_inodenumber[0];//"."
	Inode directory_inode;
	Read_Inode(directory_inode, directory_inode_index);
	//���뵱ǰĿ¼
	for (int i = 2; i < SUBDIRECTORY_NUM; i++)
	{
		if (strlen(directory.d_filename[i]) == 0)
		{
			strcat(directory.d_filename[i], file_name);
			directory.d_inodenumber[i] = new_inode.i_number;
			break;
		}
	}
	//fd.open(DISK_NAME, ios::out | ios::in | ios::binary);
	//fd.seekg((BLOCK_POSITION + directory_inode.i_addr[0]) * BLOCK_SIZE, ios::beg);      //*************//
	//fd.write((char*)&directory, sizeof(directory));
	//fd.close();

	tool_bufferpoint = buffermanager.GetBlk(directory_inode.i_addr[0]);
	memcpy(tool_bufferpoint->addr, (char*)&directory, sizeof(directory));
	buffermanager.Bwrite(tool_bufferpoint);


	//���³�����
	//Read_SuperBlock(superblock);
	memcpy((char*)&superblock, mmapoint, sizeof(SuperBlock));
	superblock.s_finodenum--;
	//Write_SuperBlock(superblock);
	memcpy(mmapoint, (char*)&superblock, sizeof(SuperBlock));
}

//ɾ��һ���ļ�
void Delete_File(const char* file_name)
{
	//����ļ����Ƿ�Ϸ�
	if (file_name == NULL || strlen(file_name) > FILENAME_MAX) {
		cout << "The file name is invalid" << endl;
		throw(ERROR_INVALID_FILENAME);
	}
	//ȡ��superblock
	SuperBlock superblock;
	//Read_SuperBlock(superblock);
	memcpy((char*)&superblock, mmapoint, sizeof(SuperBlock));

	Inode inode;
	int inode_num;
	int file_index_in_directory;
	bool exist = false;
	//��⵱ǰĿ¼�Ƿ���ͬ���ļ�
	for (int i = 0; i < SUBDIRECTORY_NUM; i++) {
		if (strcmp(directory.d_filename[i], file_name) == 0) {
			inode_num = directory.d_inodenumber[i];
			Read_Inode(inode, inode_num);
			if (inode.i_mode & Inode::IFILE) {
				exist = true;
				file_index_in_directory = i;
			}
		}
	}
	if (exist == false) {
		cout << "The file name is invalid and the current directory does not exist which named " << file_name << "" << endl;
		throw(ERROR_INVALID_FILENAME);
	}

	//����ļ��Ƿ��ѱ��û���
	if (inode.i_count > 0) {
		cout << "The current file is open and cannot be deleted" << endl;
		throw(ERROR_NO_PERMISSION);
	}

	//���ɾ����Ȩ�ޣ�ɾ����Ҫ��һ��Ŀ¼��дȨ�ޣ�
	//���Ȳ�����һ��Ŀ¼
	//����User�ṹ��
	User user;
	Read_User(user);
	int directory_inode_num = directory.d_inodenumber[0];
	Inode directory_inode;
	Read_Inode(directory_inode, directory_inode_num);
	if (user_id == inode.i_uid && !(directory_inode.i_permission & Inode::OWNER_W)) {
		cout << "You do not have permission to delete the file" << endl;
		throw(ERROR_NO_PERMISSION);
	}
	else if (user_id != inode.i_uid && user.u_gid[user_id] == inode.i_gid && !(directory_inode.i_permission & Inode::GROUP_W)) {
		cout << "You do not have permission to delete the file" << endl;
		throw(ERROR_NO_PERMISSION);
	}
	else if ((user_id != inode.i_uid && user.u_gid[user_id] != inode.i_gid) && !(directory_inode.i_permission & Inode::ELSE_W)) {
		cout << "You do not have permission to delete the file" << endl;
		throw(ERROR_NO_PERMISSION);
	}


	//��ʼ����ɾ��
	//�����ͷ����е�block
	bool stop = !(inode.i_size > 0);
	while (!stop) {
		unsigned int block_num_logical = (inode.i_size - 1) / BLOCK_SIZE;
		unsigned int block_num_physical_1, block_num_physical_2, block_num_physical_3;
		Get_Block_Pysical_Num(inode, block_num_logical, block_num_physical_1, block_num_physical_2, block_num_physical_3);

		if (inode.i_size < BLOCK_SIZE)
			stop = true;

		inode.i_size -= BLOCK_SIZE;
		Free_Block(block_num_physical_1);      //�Ȱ��������ͷŵ�
		if (block_num_logical >= 6 && block_num_logical <= 261 && (block_num_logical - 6) % 128 == 0) {
			Free_Block(block_num_physical_2);   //�����6,134�����Ѿ�����һ���������ˣ��Ͱ���һ���������Ҳ�ͷŵ�
		}
		if (block_num_logical >= 262 && (block_num_logical - 262) % 128 == 0) {
			Free_Block(block_num_physical_2);  //ͬ��
		}
		if (block_num_logical >= 262 && (block_num_logical - 262) % (128 * 128) == 0) {
			Free_Block(block_num_physical_3);  //����������������Ҳ����һ���ˣ�Ҳ������һ��Ŀ��ͷŵ�
		}

	}
	//����λʾͼ���ͷ�Inode��
	unsigned int inode_bitmap[INODE_NUM];
	Read_InodeBitMap(inode_bitmap);
	inode_bitmap[inode.i_number] = 0;
	Write_InodeBitMap(inode_bitmap);

	//����Ŀ¼
	directory.d_filename[file_index_in_directory][0] = '\0';
	directory.d_inodenumber[file_index_in_directory] = -1;
	//fd.open(DISK_NAME, ios::out | ios::in | ios::binary);
	//fd.seekg((BLOCK_POSITION + directory_inode.i_addr[0]) * BLOCK_SIZE, ios::beg);   //******************//
	//fd.write((char*)&directory, sizeof(directory));
	//fd.close();

	tool_bufferpoint = buffermanager.GetBlk(directory_inode.i_addr[0]);
	memcpy(tool_bufferpoint->addr, (char*)&directory, sizeof(directory));
	buffermanager.Bwrite(tool_bufferpoint);


	//���³�����
	superblock.s_finodenum++;
	//Write_SuperBlock(superblock);
	memcpy(mmapoint, (char*)&superblock, sizeof(SuperBlock));
}


//չʾ�ļ��б�
void Show_File_List(bool detail)
{
	const int file_name_length = 25,
		type_length = 15,
		user_id_length = 15,
		user_group_length = 15,
		inode_id_length = 15,
		size_length = 15,
		permission_length = 20,
		time_length = 25;

	cout << setw(time_length) << "Edit Time" <<
		setw(type_length) << "Type" <<
		setw(size_length) << "Size(Byte)" <<
		setw(file_name_length) << "File/Directory Name";
	if (detail) {
		cout << setw(user_id_length) << "Owner Id" <<
			setw(user_group_length) << "Owner Group" <<
			setw(inode_id_length) << "Inode Id" <<
			setw(permission_length) << "O[RWE]G[RWE]E[RWE]";
	}

	cout << endl;


	for (int i = 0; i < SUBDIRECTORY_NUM; i++) {
		if (strlen(directory.d_filename[i]) > 0) {
			Inode inode;
			Read_Inode(inode, directory.d_inodenumber[i]);

			char time[80];
			strftime(time, 80, "%Y-%m-%d %H:%M:%S", localtime(&inode.i_time));

			cout << setw(time_length) << time;
			cout << setw(type_length) << ((inode.i_mode & Inode::IDIRECTORY) ? "<DIR>" : "");
			cout << setw(size_length) << ((inode.i_mode & Inode::IDIRECTORY) ? " " : to_string(inode.i_size));
			cout << setw(file_name_length) << directory.d_filename[i];
			if (detail) {
				char tmp[16] = { bitset<9>(inode.i_permission).to_string()[0], bitset<9>(inode.i_permission).to_string()[1], bitset<9>(inode.i_permission).to_string()[2],' ',
				bitset<9>(inode.i_permission).to_string()[3], bitset<9>(inode.i_permission).to_string()[4], bitset<9>(inode.i_permission).to_string()[5],' ',
				bitset<9>(inode.i_permission).to_string()[6], bitset<9>(inode.i_permission).to_string()[7], bitset<9>(inode.i_permission).to_string()[8],'\0' };
				cout << setw(user_id_length) << inode.i_uid <<
					setw(user_group_length) << inode.i_gid <<
					setw(inode_id_length) << inode.i_number <<
					setw(permission_length) << tmp;
			}
			cout << endl;

		}
	}

}

//�����ļ����ƴ�һ����ǰĿ¼���ļ�
File* Open_File(const char* file_name)
{
	//����ļ����Ƿ�Ϸ�
	if (file_name == NULL || strlen(file_name) > FILENAME_MAX) {
		cout << "The file name is invalid" << endl;
		throw(ERROR_INVALID_FILENAME);
	}

	//�����ļ��Ƿ����
	Inode inode;
	int inode_num;
	bool exist = false;
	//��⵱ǰĿ¼�Ƿ���ͬ���ļ�
	for (int i = 0; i < SUBDIRECTORY_NUM; i++) {
		if (strcmp(directory.d_filename[i], file_name) == 0) {
			inode_num = directory.d_inodenumber[i];
			Read_Inode(inode, inode_num);
			if (inode.i_mode & Inode::IFILE) {
				exist = true;
			}
		}
	}
	if (exist == false) {
		cout << "The file name is invalid and the current directory does not exist which named " << file_name << "" << endl;
		throw(ERROR_INVALID_FILENAME);
	}

	//���ü���++
	inode.i_count++;
	//����ʱ���޸�
	inode.i_time = time(NULL);
	Write_Inode(inode, inode_num);

	File* file = new File;
	file->f_inodeid = inode_num;
	file->f_offset = 0;
	file->f_uid = user_id;

	return file;
}

//�����ļ��ṹ��ر�һ���ļ�
void Close_File(File* file)
{
	Inode inode;
	int inode_num = file->f_inodeid;
	Read_Inode(inode, inode_num);

	//��鵱ǰ�û��ǲ����ļ��Ĵ���
	if (user_id != file->f_uid) {
		cout << "Non-file open users cannot close files" << endl;
		throw(ERROR_NO_PERMISSION);
	}

	//���ü���++
	inode.i_count--;
	//����ʱ���޸�
	inode.i_time = time(NULL);
	Write_Inode(inode, inode_num);

	delete file;
}

//д�ļ�
unsigned int Write_File(File* file, string content)
{
	Inode inode;
	int inode_num = file->f_inodeid;
	Read_Inode(inode, inode_num);
	User user;
	Read_User(user);


	//��鵱ǰ�û��ǲ����ļ��Ĵ���
	if (user_id != file->f_uid) {
		cout << "Non-file open users cannot write to files" << endl;
		throw(ERROR_NO_PERMISSION);
	}
	//���Ȩ��
	if (user_id == inode.i_uid && !(inode.i_permission & Inode::OWNER_W)) {
		cout << "The current user does not have permission to write to the file" << endl;
		throw(ERROR_NO_PERMISSION);
	}
	else if (user_id != inode.i_uid && user.u_gid[user_id] == inode.i_gid && !(inode.i_permission & Inode::GROUP_W)) {
		cout << "The current user does not have permission to write to the file" << endl;
		throw(ERROR_NO_PERMISSION);
	}
	else if ((user_id != inode.i_uid && user.u_gid[user_id] != inode.i_gid) && !(inode.i_permission & Inode::ELSE_W)) {
		cout << "The current user does not have permission to write to the file" << endl;
		throw(ERROR_NO_PERMISSION);
	}

	//����ļ���С�Ƿ��ѵ��Ｋ��
	if (file->f_offset + content.size() + 1 > BLOCK_SIZE * (6 + 2 * 128 + 2 * 128 * 128 - 2)) {
		cout << "The maximum length of the file has been exceeded" << endl;
		throw(ERROR_OUT_OF_SPACE);
	}

	//��ǰҪд���blocknum
	unsigned int block_num_logical;
	unsigned int block_num_physical;
	unsigned int content_offset = 0;

	while (content_offset < content.size()) {
		//�����ǰ�黹δ���������������
		block_num_logical = (file->f_offset) / BLOCK_SIZE;
		if (file->f_offset == inode.i_size && (inode.i_size % BLOCK_SIZE == 0)) {
			//�����
			if (block_num_logical <= 5) {
				Allocate_Block(block_num_physical);
				inode.i_addr[block_num_logical] = block_num_physical;
			}
			else if (block_num_logical >= 6 && block_num_logical <= 261) {
				if ((block_num_logical - 6) % 128 == 0) {
					Allocate_Block(block_num_physical);
					inode.i_addr[(block_num_logical - 6) / 128 + 6] = block_num_physical;
				}
				unsigned int block_map_1[128];

				//fd.open(DISK_NAME, ios::out | ios::in | ios::binary);
				//fd.seekg((inode.i_addr[(block_num_logical - 6) / 128 + 6] + BLOCK_POSITION) * BLOCK_SIZE, ios::beg);  //**************//
				//fd.read((char*)block_map_1, sizeof(block_map_1));
				//fd.close();

				tool_bufferpoint = buffermanager.Bread(inode.i_addr[(block_num_logical - 6) / 128 + 6]);
				memcpy((char*)block_map_1, tool_bufferpoint->addr, sizeof(block_map_1));
				buffermanager.Brelse(tool_bufferpoint);


				Allocate_Block(block_num_physical);
				block_map_1[(block_num_logical - 6) % 128] = block_num_physical;


				//fd.open(DISK_NAME, ios::out | ios::in | ios::binary);
				//fd.seekg((inode.i_addr[(block_num_logical - 6) / 128 + 6] + BLOCK_POSITION) * BLOCK_SIZE, ios::beg);  //****************//
				//fd.write((char*)block_map_1, sizeof(block_map_1));
				//fd.close();

				tool_bufferpoint = buffermanager.GetBlk(inode.i_addr[(block_num_logical - 6) / 128 + 6]);
				memcpy(tool_bufferpoint->addr, (char*)block_map_1, sizeof(block_map_1));
				buffermanager.Bwrite(tool_bufferpoint);
			}
			else if (block_num_logical >= 262) {
				unsigned int block_map_1[128], block_map_2[128];
				if ((block_num_logical - 262) % (128 * 128) == 0) {
					Allocate_Block(block_num_physical);
					inode.i_addr[(block_num_logical - 262) / 128 / 128 + 8] = block_num_physical;
				}
				if ((block_num_logical - 262) % 128 == 0) {
					Allocate_Block(block_num_physical);

					//fd.open(DISK_NAME, ios::out | ios::in | ios::binary);
					//fd.seekg((inode.i_addr[(block_num_logical - 262) / 128 / 128 + 8] + BLOCK_POSITION) * BLOCK_SIZE, ios::beg);  //***********//
					//fd.read((char*)block_map_1, sizeof(block_map_1));
					//fd.close();
					tool_bufferpoint = buffermanager.Bread(inode.i_addr[(block_num_logical - 262) / 128 / 128 + 8]);
					memcpy((char*)block_map_1, tool_bufferpoint->addr, sizeof(block_map_1));
					buffermanager.Brelse(tool_bufferpoint);
					
					block_map_1[(block_num_logical - 262) / 128 % 128] = block_num_physical;
					
					//fd.open(DISK_NAME, ios::out | ios::in | ios::binary);
					//fd.seekg((inode.i_addr[(block_num_logical - 262) / 128 / 128 + 8] + BLOCK_POSITION) * BLOCK_SIZE, ios::beg);//***********//
					//fd.write((char*)block_map_1, sizeof(block_map_1));
					//fd.close();

					tool_bufferpoint = buffermanager.GetBlk(inode.i_addr[(block_num_logical - 262) / 128 / 128 + 8]);
					memcpy(tool_bufferpoint->addr, (char*)block_map_1, sizeof(block_map_1));
					buffermanager.Bwrite(tool_bufferpoint);

				}
				//fd.open(DISK_NAME, ios::out | ios::in | ios::binary);
				//fd.seekg((inode.i_addr[(block_num_logical - 262) / 128 / 128 + 8] + BLOCK_POSITION) * BLOCK_SIZE, ios::beg);  //***********//
				//fd.read((char*)block_map_1, sizeof(block_map_1));

				tool_bufferpoint = buffermanager.Bread(inode.i_addr[(block_num_logical - 262) / 128 / 128 + 8]);
				memcpy((char*)block_map_1, tool_bufferpoint->addr, sizeof(block_map_1));
				buffermanager.Brelse(tool_bufferpoint);


				//fd.seekg((block_map_1[(block_num_logical - 262) / 128 % 128] + BLOCK_POSITION) * BLOCK_SIZE, ios::beg);       //***********//
				//fd.read((char*)block_map_2, sizeof(block_map_2));
				//fd.close();

				tool_bufferpoint = buffermanager.Bread(block_map_1[(block_num_logical - 262) / 128 % 128]);
				memcpy((char*)block_map_2, tool_bufferpoint->addr, sizeof(block_map_2));
				buffermanager.Brelse(tool_bufferpoint);


				Allocate_Block(block_num_physical);
				block_map_2[(block_num_logical - 262) % 128] = block_num_physical;


				//fd.open(DISK_NAME, ios::out | ios::in | ios::binary);
				//fd.seekg((block_map_1[(block_num_logical - 262) / 128 % 128] + BLOCK_POSITION) * BLOCK_SIZE, ios::beg);      //************//
				//fd.write((char*)block_map_2, sizeof(block_map_2));
				//fd.close();

				tool_bufferpoint = buffermanager.GetBlk(block_map_1[(block_num_logical - 262) / 128 % 128]);
				memcpy(tool_bufferpoint->addr, (char*)block_map_2, sizeof(block_map_2));
				buffermanager.Bwrite(tool_bufferpoint);
			}
		}
		unsigned int tmp2, tmp3;
		Get_Block_Pysical_Num(inode, block_num_logical, block_num_physical, tmp2, tmp3);
		//�ڵ�ǰ��д���λ��
		unsigned int block_offset;
		block_offset = file->f_offset % BLOCK_SIZE;
		//������Ҫд����ֽ���
		unsigned int write_byte_num;
		write_byte_num = (content.size() - content_offset) >= (BLOCK_SIZE - block_offset) ? BLOCK_SIZE - block_offset : content.size() - content_offset;

		//���ڴ��ж����ÿ�����
		char block_content[BLOCK_SIZE];
		tool_bufferpoint = buffermanager.Bread(block_num_physical);
		string sub = content.substr(content_offset, write_byte_num);
		memcpy(tool_bufferpoint->addr + block_offset, sub.c_str(), write_byte_num);
		buffermanager.Bwrite(tool_bufferpoint);


		//fd.open(DISK_NAME, ios::out | ios::in | ios::binary);
		//fd.seekg(BLOCK_SIZE * (BLOCK_POSITION + block_num_physical), ios::beg);   ////////////////////////�����ǲ��ǰ�BLOCK_POSITIONд����BLOCK_NUM
		//fd.read(block_content, sizeof(block_content));                            //********************//
		//fd.close();
		////������д���ڴ�
		//string sub = content.substr(content_offset, write_byte_num);
		////memcpy(block_content + block_offset, content + content_offset, write_byte_num);
		//memcpy(block_content + block_offset, sub.c_str(), write_byte_num);
		//fd.open(DISK_NAME, ios::out | ios::in | ios::binary);
		//fd.seekg(BLOCK_SIZE * (BLOCK_POSITION + block_num_physical), ios::beg);////////////////////////��������
		//fd.write(block_content, sizeof(block_content));                           //*******************//
		//fd.close();

		content_offset += write_byte_num;
		file->f_offset += write_byte_num;
		if (file->f_offset > inode.i_size)
			inode.i_size = file->f_offset;
	}
	inode.i_time = time(NULL);

	Write_Inode(inode, inode_num);
	return content.size();
}

//�����ļ�ָ��
void Seek_File(File* file, unsigned int pos)
{
	Inode inode;
	int inode_num = file->f_inodeid;
	Read_Inode(inode, inode_num);
	User user;
	Read_User(user);

	//��鵱ǰ�û��ǲ����ļ��Ĵ���
	if (user_id != file->f_uid) {
		cout << "Non-file open users cannot change the file pointer" << endl;
		throw(ERROR_NO_PERMISSION);
	}

	//���Ȩ��
	if (user_id == inode.i_uid && !(inode.i_permission & Inode::OWNER_W)) {
		cout << "The current user does not have permission to make pointer changes to the file" << endl;
		throw(ERROR_NO_PERMISSION);
	}
	else if (user_id != inode.i_uid && user.u_gid[user_id] == inode.i_gid && !(inode.i_permission & Inode::GROUP_W)) {
		cout << "The current user does not have permission to make pointer changes to the file" << endl;
		throw(ERROR_NO_PERMISSION);
	}
	else if ((user_id != inode.i_uid && user.u_gid[user_id] != inode.i_gid) && !(inode.i_permission & Inode::ELSE_W)) {
		cout << "The current user does not have permission to make pointer changes to the file" << endl;
		throw(ERROR_NO_PERMISSION);
	}

	if (inode.i_size < pos) {
		cout << "The file pointer position entered is larger than the file length and is positioned at the end of the file" << endl;
	}
	file->f_offset = (inode.i_size < pos) ? inode.i_size : pos;


	Write_Inode(inode, inode_num);
}

//���ļ�
unsigned int Read_File(File* file, char* content, int length)
{
	Inode inode;
	int inode_num = file->f_inodeid;
	Read_Inode(inode, inode_num);
	User user;
	Read_User(user);

	int len_sum = 0;
	//��鵱ǰ�û��ǲ����ļ��Ĵ���
	if (user_id != file->f_uid) {
		cout << "Non-file open users cannot read files" << endl;
		throw(ERROR_NO_PERMISSION);
	}
	//���Ȩ��
	if (user_id == inode.i_uid && !(inode.i_permission & Inode::OWNER_R)) {
		cout << "The current user does not have permission to read the file" << endl;
		throw(ERROR_NO_PERMISSION);
	}
	else if (user_id != inode.i_uid && user.u_gid[user_id] == inode.i_gid && !(inode.i_permission & Inode::GROUP_R)) {
		cout << "The current user does not have permission to read the file" << endl;
		throw(ERROR_NO_PERMISSION);
	}
	else if ((user_id != inode.i_uid && user.u_gid[user_id] != inode.i_gid) && !(inode.i_permission & Inode::ELSE_R)) {
		cout << "The current user does not have permission to read the file" << endl;
		throw(ERROR_NO_PERMISSION);
	}

	unsigned int block_num_logical;
	unsigned int block_num_physical;
	unsigned int content_offset = 0;
	while (file->f_offset < inode.i_size && (content_offset < length || length == -1)) {
		block_num_logical = (file->f_offset) / BLOCK_SIZE;
		unsigned int tmp2, tmp3;
		Get_Block_Pysical_Num(inode, block_num_logical, block_num_physical, tmp2, tmp3);

		unsigned int read_byte_num;
		read_byte_num = ((inode.i_size - file->f_offset) < (BLOCK_SIZE - file->f_offset % BLOCK_SIZE)) ? inode.i_size - file->f_offset : (BLOCK_SIZE - file->f_offset % BLOCK_SIZE);
		if (length != -1)
			read_byte_num = (read_byte_num < (length - content_offset)) ? read_byte_num : (length - content_offset);

		char block_content[BLOCK_SIZE];
		//fd.open(DISK_NAME, ios::out | ios::in | ios::binary);
		//fd.seekg(BLOCK_SIZE * (BLOCK_POSITION + block_num_physical), ios::beg);        //����Ҳ�������� ��line447����      //******************//
		//fd.read(block_content, sizeof(block_content));
		//fd.close();
		tool_bufferpoint = buffermanager.Bread(block_num_physical);

		//memcpy(content + content_offset, block_content + file->f_offset % BLOCK_SIZE, read_byte_num);
		memcpy(content + content_offset, tool_bufferpoint->addr + file->f_offset % BLOCK_SIZE, read_byte_num);

		buffermanager.Brelse(tool_bufferpoint);

		len_sum += read_byte_num;
		content_offset += read_byte_num;
		content[content_offset] = '\0';
		file->f_offset += read_byte_num;
	}
	content[content_offset] = '\0';
	return len_sum;
}

//����һ���ļ���Ȩ��
void Edit_File_Permission(const char* directory_name, unsigned short permission, bool add)       //���������֤һ���û���Ϣ
{
	if (directory_name == NULL) {
		cout << "The path name is invalid" << endl;
		throw(ERROR_INVALID_PATH);
	}

	if (user_id != 0) {
		cout << "Only the root user can make file permission changes" << endl;
		throw(ERROR_NO_PERMISSION);
	}


	char* reached_path = new char[strlen(directory_name) + 2];
	reached_path[0] = '\0';

	Directory current_directory = directory;
	unsigned int current_inode = 0;

	int index = 0;
	
	while (strlen(reached_path) < strlen(directory_name)) {
		char to_dir[FILE_NAME_MAX];
		for (int i = 0;; i++, index++) {
			if (directory_name[index] == '\\' || directory_name[index] == '/' || directory_name[index] == '\0') {
				to_dir[i] = '\0';
				index++;
				break;
			}
			to_dir[i] = directory_name[index];
		}
		bool find = false;
		//����Ŀ¼
		for (int i = 0; i < SUBDIRECTORY_NUM; i++) {
			if (strcmp(to_dir, current_directory.d_filename[i]) == 0) {
				Inode to_inode;
				current_inode = current_directory.d_inodenumber[i];
				Read_Inode(to_inode, current_inode);

				if (to_inode.i_mode == Inode::IDIRECTORY) {
					find = true;
					strcat(reached_path, to_dir);
					strcat(reached_path, "/");

					//����current_directory
					//fd.open(DISK_NAME, ios::out | ios::in | ios::binary);
					//fd.seekg(BLOCK_SIZE * (BLOCK_POSITION + to_inode.i_addr[0]), ios::beg);       //****************//
					//fd.read((char*)&current_directory, sizeof(current_directory));
					//fd.close();

					tool_bufferpoint = buffermanager.Bread(to_inode.i_addr[0]);
					memcpy((char*)&current_directory, tool_bufferpoint->addr, sizeof(current_directory));
					buffermanager.Brelse(tool_bufferpoint);



					break;
				}
				else {
					strcat(reached_path, to_dir);
					//�ҵ��ļ�
					if (strlen(reached_path) == strlen(directory_name)) {
						find = true;
					}
				}
			}
		}
		if (find == false) {
			cout << "The directory is not legitimate" << endl;
			throw(ERROR_INVALID_PATH);
		}
	}
	Inode file_inode;
	Read_Inode(file_inode, current_inode);
	if (add)
		file_inode.i_permission = file_inode.i_permission | permission;
	else
		file_inode.i_permission = file_inode.i_permission & ~permission;

	Write_Inode(file_inode, current_inode);

	delete[] reached_path;
}
